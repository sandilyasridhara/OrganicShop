import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class CategoryService {
  // labels: any;
  categories: Observable<any[]>;

  constructor(private db: AngularFireDatabase) {
  }

  getCategories() {
     return this.categories =  this.db.list('/categories').snapshotChanges();
    //  .subscribe(res => {
    //      console.log(res) //should give you the array of percentage.
    //      this.categories = res;
    //       valuechanges();
     }
  }

