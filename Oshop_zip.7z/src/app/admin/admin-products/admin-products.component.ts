import { Component, OnInit, OnDestroy } from '@angular/core';
import { ProductService } from 'src/app/product.service';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs';
import { Product } from 'src/app/models/product';

@Component({
  selector: 'app-admin-products',
  templateUrl: './admin-products.component.html',
  styleUrls: ['./admin-products.component.css']
})
export class AdminProductsComponent implements OnInit {
 products$ : Observable<any[]>;
 // products: Product[];

  // subscription: Subscription;
  // filterdProducts: any[];
  constructor(private productService: ProductService) {

     this.products$ = this.productService.getAll();
    //console.log(this.products$);
    // this.subscription =  this.productService
    // .getAll().subscribe(products => this.filterdProducts = this.products = products);
  
   }

    filter(query: string) {
    console.log(query);
    }
    
    
  //   this.filterdProducts = (query) ?
  //   this.products.filter(p => p.title.toLowerCase().includes(query.toLowerCase())) :
  //   this.products;
  //   console.log(this.filterdProducts);
  //  }
  //  ngOnDestroy() {
  //   this.subscription.unsubscribe();
  //  }

  ngOnInit() {
     //this.productService.getAll();
  }

}
