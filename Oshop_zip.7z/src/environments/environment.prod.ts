export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyAcOBKIjK_nToJeKqLpockneCxdqfe92Y0",
    authDomain: "oshop-226ff.firebaseapp.com",
    databaseURL: "https://oshop-226ff.firebaseio.com",
    projectId: "oshop-226ff",
    storageBucket: "oshop-226ff.appspot.com",
    messagingSenderId: "242295797005"
  }
};
